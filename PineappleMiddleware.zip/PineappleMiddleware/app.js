const express = require('express');

const app = express();

app.use((req, res, next) => {//"use method sets up middleware"?
	res.status(200).json({
		message: 'It works'
	});
});

module.exports = app;