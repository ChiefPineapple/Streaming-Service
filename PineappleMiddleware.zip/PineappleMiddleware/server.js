const http = require('http');
const app = require('./app');
const port = process.env.PORT || 3000; //process.env.PORT is environment variable that might be set by apache?

const server = http.createServer();

server.listen(port);
